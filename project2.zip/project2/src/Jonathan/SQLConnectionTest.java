package Jonathan;

import junit.framework.TestCase;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
//import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import org.junit.BeforeClass;

/**
 * Created by ��ϲ on 2017/8/27.
 */
public class SQLConnectionTest extends TestCase {


    public void testConnectToDatabase() throws Exception {
        assertEquals(true,new SQLConnection().connectToDatabase("localhost:3306", "dbgirl", "root", "111"));
    }

    public void testCloseConn() throws Exception {//�޷���ֵ

    }

    public void testChkLoginInfo() throws Exception {
        SQLConnection DB = new SQLConnection();
        DB.connectToDatabase("localhost:3306", "dbgirl", "root", "111") ;
        assertEquals(SQLConnection.SUCCESS,DB.chkLoginInfo("123", "123"));
        assertEquals(SQLConnection.PSWD_ERROR,DB.chkLoginInfo("123", "798"));
        assertEquals(SQLConnection.USER_INEXIST,DB.chkLoginInfo("123456789", "123"));
    }

    public void testGetLoginId() throws Exception {
        SQLConnection DB = new SQLConnection();
        DB.connectToDatabase("localhost:3306", "dbgirl", "root", "111") ;
        assertEquals(1, DB.getLoginId("123"));
        assertEquals(-1, DB.getLoginId("123456789"));
    }

    public void testAddLoginInfo() throws Exception {
        SQLConnection DB = new SQLConnection();
        DB.connectToDatabase("localhost:3306", "dbgirl", "root", "111") ;
        assertEquals(SQLConnection.USER_EXIST, DB.addLoginInfo("123", "123"));
        assertEquals(SQLConnection.SUCCESS, DB.addLoginInfo("159", "159"));

    }

    public void testCreateCalendarForNow() throws Exception {
        //Calendar c=Calendar.getInstance();
        //assertEquals(c,new SQLConnection().createCalendarForNow());
    }

    public void testCreateCalendar() throws Exception {
        Calendar c=Calendar.getInstance();
        c.set(2017,6,7,0,0,0);
        assertEquals(c.getTime().toString(),new SQLConnection().createCalendar(2017,7,7).getTime().toString());
    }

    public void testCreateCalendarByString() throws Exception {
        Calendar c=Calendar.getInstance();
        c.set(2017, 5, 7, 0, 0, 0);
        assertEquals(c.getTime().toString(),new SQLConnection().createCalendarByString("2017/06/07").getTime().toString());
    }

    public void testGetProposalByUName() throws Exception {

    }

    public void testGetProposalById() throws Exception {

        SQLConnection DB=new SQLConnection();
        DB.connectToDatabase("localhost:3306", "dbgirl", "root", "111") ;
        User U=new User(2,"11111",'1',DB.createCalendar(1997,8,07),"11111","1",1,-1,-1,100,'1');
        Proposal P=new Proposal(U,"ffff","i have a apple.",DB.createCalendar(2017,8,26),DB.createCalendar(1997,01,01),2,3);
        assertEquals(P.toString(), DB.getProposalById(1).toString());
        User U2=new User(6,"Сֱ",'M',DB.createCalendar(1997,2,7),"������ҵ��ѧ","13522553799",-1,-1,-1,100,'5');
        Proposal P2=new Proposal(U2,"�����������ɴ��","���ἱ�ڸ��������ɴ����ɴ�����˽��˺ö����ӣ�������",DB.createCalendar(2017,8,27),DB.createCalendar(2017,9,10),100,0);
        assertEquals(P2.toString(),DB.getProposalById(8).toString());
    }

    public void testGetProposalByTitle() throws Exception {

    }

    public void testGetProposalForAll() throws Exception {

    }

    public void testAddProposal() throws Exception {

    }

    public void testAddCommentForProposal() throws Exception {

    }

    public void testGetCommentForProposal() throws Exception {

    }

    public void testGetStandardByWriter() throws Exception {

    }

    public void testGetStandardById() throws Exception {

    }

    public void testGetStangardByTitle() throws Exception {

    }

    public void testGetStandardForAll() throws Exception {

    }

    public void testAddStandard() throws Exception {

    }

    public void testAddCommentForStandard() throws Exception {

    }

    public void testGetCommentForStandard() throws Exception {

    }

    public void testAddStandardToProposal() throws Exception {

    }

    public void testChkAllStandardUnderProposal() throws Exception {

    }

    public void testChkUserForAll() throws Exception {

    }

    public void testChkUserByName() throws Exception {

    }

    public void testAddUser() throws Exception {

    }

    public void testChkUserById() throws Exception {

    }

    public void testGetEnrollRequestFor() throws Exception {

    }

    public void testPermitEnrollRequest() throws Exception {

    }

    public void testRejectEnrollRequest() throws Exception {

    }

    public void testMain() throws Exception {

    }
}